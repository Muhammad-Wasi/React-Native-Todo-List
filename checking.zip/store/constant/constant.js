const ActionTypes = {
    LIST: 'LIST'
}

export default ActionTypes;
