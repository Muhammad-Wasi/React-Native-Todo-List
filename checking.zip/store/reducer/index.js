import reducer from './rootRreducer';
import {combineReducers} from 'redux';

export default combineReducers({
    root: reducer
});

